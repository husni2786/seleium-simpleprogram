package com.pages;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;


public class JournalsBySubject 
{
	        WebDriver driver;
	        Actions action;
			Logger LOG = Logger.getLogger(LoginAcademicOUP.class.getName());
			
			@FindBy(linkText = "Journals by Subject")
			WebElement journals;
			@FindBy(linkText ="Medicine & Health")
			WebElement medicine;
			
			
			public JournalsBySubject(WebDriver driver)
			{
				
				PageFactory.initElements(driver, this);
				this.driver=driver;
			}
			
			public void journals_bysubject()
			{
				
				  action = new Actions(driver);
				  action.moveToElement(journals).build().perform();
				  LOG.info("mouse is moved on customer service button");
				  Actions seriesofactions = action.moveToElement(medicine).click();
				  seriesofactions.build().perform();
				  LOG.info("Clicked about us button");
				
				
			}
			
			

		}






