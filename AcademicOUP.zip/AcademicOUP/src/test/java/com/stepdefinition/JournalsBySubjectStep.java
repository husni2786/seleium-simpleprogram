package com.stepdefinition;

import java.io.IOException;

import com.base.Library;
import com.pages.JournalsBySubject;
import com.seleniumutility.SeleUtil;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class JournalsBySubjectStep extends Library
{
	SeleUtil util;
	JournalsBySubject subject;
	
	@Given("^I launch the webbrowser$")
	public void i_launch_the_webbrowser() throws IOException 
	{
	   
		launchBrowser(); 
		System.out.println("Browser is Launched");	
		
	}
	
	@When("^JournalsBySubject page is Opened$")
	public void journalsbysubject_page_is_Opened() 
	{
		
		util = new SeleUtil(driver);
		util.ScreenShot("C:\\Users\\lenovo\\eclipse-workspace1\\AcademicOUP\\src\\test\\resources\\ScreenShot\\JournalsBySubject.png");
		System.out.println("ScreenShot is Successfully Taken");
	   
	}

	@Then("^I click on that button$")
	public void i_click_on_that_button() 
	{
		subject = new JournalsBySubject(driver);
		subject.journals_bysubject();
		 System.out.println("Clicked on JournalsBySubject and its sub Medicine&Health buttons");
	}

}
