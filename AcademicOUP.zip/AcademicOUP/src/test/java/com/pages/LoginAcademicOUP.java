package com.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class LoginAcademicOUP 
{
	
		
		WebDriver driver;
		
		//Identifying the Locators
		@FindBy(xpath = "//*[@id='header-account-info-user-fullname']")  
		WebElement signinbtn; 
		
		@FindBy(id = "user_LoginFormPopup")
		WebElement username;
		@FindBy(id = "pass_LoginFormPopup")
		WebElement password;
		@FindBy(xpath = "//button[contains(text(),'Sign In')]")
		WebElement loginbtn;
		
		//Pointing to the current driver
		public LoginAcademicOUP(WebDriver driver)
		{
		    PageFactory.initElements(driver, this);
			this.driver=driver;
		}
		
		//Clicking on the Signin icon
		public void login_signininspect()
		{
			signinbtn.click();
		}
		
		//Entering the UserName
		public void login_username(String userid)
		{
		      username.sendKeys(userid);
		}
		
		//Entering the Password
		public void login_password(String pwd)
		{
			password.sendKeys(pwd);
		}
		
		//Clicking on the Sigin Button
		public void login_button()
		{
			WebDriverWait wait = new WebDriverWait(driver , 20);
			wait.until(ExpectedConditions.elementToBeClickable(loginbtn));
			loginbtn.click();
			//Closing the Driver
			driver.close();
		}
		

	}



